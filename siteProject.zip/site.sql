
create table siteMember(
id varchar(100) primary key,
pw varchar(100),
name varchar(100),
tel varchar(100),
addr varchar(100),
favorite varchar(100)
);

create table bbs(
bid varchar(100),
pw varchar(100),
title varchar(100),
content varchar(100),
bbsDate varchar(100)
);



